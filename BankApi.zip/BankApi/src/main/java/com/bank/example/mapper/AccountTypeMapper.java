package com.bank.example.mapper;

import com.bank.example.dto.AccountTypeDto;
import com.bank.example.entity.AccountType;

public class AccountTypeMapper implements IMapper<AccountTypeDto, AccountType>{

	@Override
	public AccountType convetDtoToEntity(AccountTypeDto dto) {
		final AccountType entity = new AccountType();
		entity.setAccountTypeId(dto.getAccountTypeId());
		entity.setAccountTypeName(dto.getAccountTypeName());
		return entity;
	}

	@Override
	public AccountTypeDto convertEntityToDto(AccountType entity) {
		final AccountTypeDto dto = new AccountTypeDto();
		dto.setAccountTypeId(entity.getAccountTypeId());
		dto.setAccountTypeName(entity.getAccountTypeName());
		return dto;
	}

	

}
