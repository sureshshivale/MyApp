package com.bank.example.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the ACCOUNT_TYPE database table.
 * 
 */
@Entity
@Table(name="ACCOUNT_TYPE")
public class AccountType implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="ACCOUNT_TYPE_ACCOUNTTYPEID_GENERATOR" )
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ACCOUNT_TYPE_ACCOUNTTYPEID_GENERATOR")
	@Column(name="ACCOUNT_TYPE_ID")
	private long accountTypeId;

	@Column(name="ACCOUNT_TYPE_NAME")
	private String accountTypeName;

	public long getAccountTypeId() {
		return accountTypeId;
	}

	public void setAccountTypeId(long accountTypeId) {
		this.accountTypeId = accountTypeId;
	}

	public String getAccountTypeName() {
		return accountTypeName;
	}

	public void setAccountTypeName(String accountTypeName) {
		this.accountTypeName = accountTypeName;
	}

}