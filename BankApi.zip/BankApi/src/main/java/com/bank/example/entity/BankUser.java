package com.bank.example.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


/**
 * The persistent class for the BANK_USER database table.
 * 
 */
@Entity
@Table(name="BANK_USER")
public class BankUser implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="LOGIN_STATUS")
	private String loginStatus;

	private String password;

	@Id
	@Column(name="USER_NAME")
	private String userName;

	public String getLoginStatus() {
		return loginStatus;
	}

	public void setLoginStatus(String loginStatus) {
		this.loginStatus = loginStatus;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

}