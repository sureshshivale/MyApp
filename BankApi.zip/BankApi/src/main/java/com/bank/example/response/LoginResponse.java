package com.bank.example.response;

import java.io.Serializable;

import com.bank.example.dto.BankUserDto;

public class LoginResponse extends ResponseMessage implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private BankUserDto bankUser;

	public BankUserDto getBankUser() {
		return bankUser;
	}

	public void setBankUser(BankUserDto bankUser) {
		this.bankUser = bankUser;
	}
}
