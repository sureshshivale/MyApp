package com.bank.example.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.bank.example.entity.BankUser;

public interface BankUserRepository extends CrudRepository<BankUser,Long>{

	@Query("SELECT bankUser FROM BankUser bankUser WHERE bankUser.userName=:userName and bankUser.password=:password")
	public BankUser findUserByName(@Param("userName") String userName, @Param("password") String password);
}
