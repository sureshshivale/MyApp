package com.bank.example.response;

import java.io.Serializable;
import java.util.List;

import com.bank.example.dto.AccountBranchDto;

public class BranchResponse extends ResponseMessage implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private List<AccountBranchDto> accountBranch;

	public List<AccountBranchDto> getAccountBranch() {
		return accountBranch;
	}

	public void setAccountBranch(List<AccountBranchDto> accountBranch) {
		this.accountBranch = accountBranch;
	}

}
