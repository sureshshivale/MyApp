package com.bank.example.service;

import com.bank.example.request.AccountRequest;
import com.bank.example.request.LoginRequest;
import com.bank.example.request.TransactionRequest;
import com.bank.example.response.AccountResponse;
import com.bank.example.response.AccountTypeResponse;
import com.bank.example.response.BranchResponse;
import com.bank.example.response.LoginResponse;
import com.bank.example.response.TransactionResponse;

public interface IBankService {

	public LoginResponse appLogin(final LoginRequest loginRequest);
	public LoginResponse appLoginOut(final LoginRequest loginRequest);

	public AccountResponse addAccount(final AccountRequest accountRequest);
	public AccountResponse viewAccount(final AccountRequest accountRequest);
	public AccountResponse deleteAccount(final AccountRequest accountRequest);
	
	public TransactionResponse accountDeposit(final TransactionRequest transactionRequest);
	public TransactionResponse accountWithdraw(final TransactionRequest transactionRequest);
	
	public AccountTypeResponse getAccountType();
	public BranchResponse getBranch();
}
