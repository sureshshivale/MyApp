package com.bank.example.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.bank.example.entity.Transaction;

public interface TransactionRepository extends CrudRepository<Transaction,Long>{

	@Query("SELECT transaction FROM Transaction transaction WHERE transaction.account.accountId=:accountId AND transaction.transactionType=:transactionType")
	List<Transaction> findTransactionByAcctIdAndTransType(@Param("accountId") Long accountId,@Param("transactionType") String transactionType);
}
