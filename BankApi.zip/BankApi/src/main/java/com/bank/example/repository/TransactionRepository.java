package com.bank.example.repository;

import org.springframework.data.repository.CrudRepository;

import com.bank.example.entity.Transaction;

public interface TransactionRepository extends CrudRepository<Transaction,Long>{

	//List<Transaction> findTransactionByAcctId(Long accountId);
	//List<Transaction> findTransactionByTransType(String transactionType);
	//List<Transaction> findTransactionByAcctIdAndTransType(Long accountId,String transactionType);
}
