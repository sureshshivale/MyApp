package com.bank.example.mapper;

import com.bank.example.dto.AccountBranchDto;
import com.bank.example.entity.AccountBranch;

public class AccountBranchMapper implements IMapper<AccountBranchDto, AccountBranch>{

	@Override
	public AccountBranch convetDtoToEntity(AccountBranchDto dto) {
		final AccountBranch entity = new AccountBranch();
		entity.setAccountBranchId(dto.getAccountBranchId());
		entity.setAccountBranchName(dto.getAccountBranchName());
		return entity;
	}

	@Override
	public AccountBranchDto convertEntityToDto(AccountBranch entity) {
		final AccountBranchDto dto = new AccountBranchDto();
		dto.setAccountBranchId(entity.getAccountBranchId());
		dto.setAccountBranchName(entity.getAccountBranchName());
		return dto;
	}

	
}
