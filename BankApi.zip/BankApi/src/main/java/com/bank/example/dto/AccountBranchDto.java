package com.bank.example.dto;

import java.io.Serializable;


public class AccountBranchDto implements Serializable {
	private static final long serialVersionUID = 1L;

	private long accountBranchId;
	private String accountBranchName;
	
	public long getAccountBranchId() {
		return accountBranchId;
	}
	public void setAccountBranchId(long accountBranchId) {
		this.accountBranchId = accountBranchId;
	}
	public String getAccountBranchName() {
		return accountBranchName;
	}
	public void setAccountBranchName(String accountBranchName) {
		this.accountBranchName = accountBranchName;
	}
	
}