package com.bank.example.dto;

import java.io.Serializable;

public class BankUserDto implements Serializable {
	private static final long serialVersionUID = 1L;

	private String loginStatus;
	private String password;
	private String userName;
	public String getLoginStatus() {
		return loginStatus;
	}
	public void setLoginStatus(String loginStatus) {
		this.loginStatus = loginStatus;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}

}