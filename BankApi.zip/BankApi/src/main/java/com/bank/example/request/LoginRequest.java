package com.bank.example.request;

import java.io.Serializable;

import com.bank.example.dto.BankUserDto;

public class LoginRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private BankUserDto bankUser;

	public BankUserDto getBankUser() {
		return bankUser;
	}

	public void setBankUser(BankUserDto bankUser) {
		this.bankUser = bankUser;
	}
	
	
}
