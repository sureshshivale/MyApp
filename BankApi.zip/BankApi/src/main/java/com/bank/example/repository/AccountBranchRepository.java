package com.bank.example.repository;

import org.springframework.data.repository.CrudRepository;

import com.bank.example.entity.AccountBranch;

public interface AccountBranchRepository extends CrudRepository<AccountBranch,Long>{

}
