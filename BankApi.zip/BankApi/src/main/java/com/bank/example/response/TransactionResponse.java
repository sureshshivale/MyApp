package com.bank.example.response;

import java.io.Serializable;
import java.util.List;

import com.bank.example.dto.TransactionDto;

public class TransactionResponse extends ResponseMessage implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private List<TransactionDto> transactions;

	public List<TransactionDto> getTransactions() {
		return transactions;
	}

	public void setTransactions(List<TransactionDto> transactions) {
		this.transactions = transactions;
	}
}
