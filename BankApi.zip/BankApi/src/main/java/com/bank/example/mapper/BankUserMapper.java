package com.bank.example.mapper;

import com.bank.example.dto.BankUserDto;
import com.bank.example.entity.BankUser;

public class BankUserMapper implements IMapper<BankUserDto, BankUser>{

	@Override
	public BankUser convertDtoToEntity(BankUserDto dto) {
		final BankUser entity = new BankUser();
		entity.setUserName(dto.getUserName());
		entity.setPassword(dto.getPassword());
		entity.setLoginStatus(dto.getLoginStatus());
		return entity;
	}

	@Override
	public BankUserDto convertEntityToDto(BankUser entity) {
		final BankUserDto dto = new BankUserDto();
		dto.setUserName(entity.getUserName());
		dto.setPassword(entity.getPassword());
		dto.setLoginStatus(entity.getLoginStatus());
		return dto;
	}

	

}
