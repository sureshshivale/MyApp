package com.bank.example.response;

import java.io.Serializable;
import java.util.List;

import com.bank.example.dto.AccountTypeDto;

public class AccountTypeResponse extends ResponseMessage implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private List<AccountTypeDto> accountTypes;

	public List<AccountTypeDto> getAccountTypes() {
		return accountTypes;
	}

	public void setAccountTypes(List<AccountTypeDto> accountTypes) {
		this.accountTypes = accountTypes;
	}

}
