package com.bank.example.service;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.example.dto.AccountBranchDto;
import com.bank.example.dto.AccountDto;
import com.bank.example.dto.AccountTypeDto;
import com.bank.example.dto.TransactionDto;
import com.bank.example.entity.Account;
import com.bank.example.entity.AccountBranch;
import com.bank.example.entity.AccountType;
import com.bank.example.entity.BankUser;
import com.bank.example.entity.Transaction;
import com.bank.example.mapper.AccountBranchMapper;
import com.bank.example.mapper.AccountMapper;
import com.bank.example.mapper.AccountTypeMapper;
import com.bank.example.mapper.BankUserMapper;
import com.bank.example.mapper.TransactionMapper;
import com.bank.example.repository.AccountBranchRepository;
import com.bank.example.repository.AccountRepository;
import com.bank.example.repository.AccountTypeRepository;
import com.bank.example.repository.BankUserRepository;
import com.bank.example.repository.TransactionRepository;
import com.bank.example.request.AccountRequest;
import com.bank.example.request.LoginRequest;
import com.bank.example.request.TransactionRequest;
import com.bank.example.response.AccountResponse;
import com.bank.example.response.AccountTypeResponse;
import com.bank.example.response.BranchResponse;
import com.bank.example.response.LoginResponse;
import com.bank.example.response.TransactionResponse;

@Service
public class BankServiceImpl implements IBankService{

	final Logger LOGGER = LoggerFactory.getLogger(BankServiceImpl.class);
	
	@Autowired
	private BankUserRepository bankUserRepository;
	
	@Autowired
	private AccountBranchRepository accountBranchRepository;
	
	@Autowired
	private AccountRepository accountRepository;
	
	@Autowired
	private AccountTypeRepository accountTypeRepository;
	
	@Autowired
	private TransactionRepository transactionRepository;
	
	@Override
	public LoginResponse appLogin(final LoginRequest loginRequest) {
		LOGGER.info("Enter in BankService :: appLogin()");
		final LoginResponse loginResponse = new LoginResponse();
		final BankUser bankUserEntity = new BankUserMapper().convertDtoToEntity(loginRequest.getBankUser());
		if(null != bankUserEntity){
			final BankUser bankUser = bankUserRepository.findUserByName(bankUserEntity.getUserName(), bankUserEntity.getPassword());
			if(null != bankUser){
				loginResponse.setBankUser(new BankUserMapper().convertEntityToDto(bankUser));
			}
		}
		LOGGER.info("Exit from BankService :: appLogin()");
		return loginResponse;
	}

	@Override
	public LoginResponse appLoginOut(final LoginRequest loginRequest) {
		LOGGER.info("Enter in BankService :: appLoginOut()");
		final LoginResponse loginResponse = new LoginResponse();
		final BankUser bankUserEntity = new BankUserMapper().convertDtoToEntity(loginRequest.getBankUser());
		if(null != bankUserEntity){
			final BankUser bankUser = bankUserRepository.findUserByName(bankUserEntity.getUserName(), bankUserEntity.getPassword());
			if(null != bankUser){
				bankUser.setLoginStatus("LOGOUT");
				bankUserRepository.save(bankUser);
				loginResponse.setCode("LOGOUT_SUCCESS");
				loginResponse.setMessage("Hey User .. applicaion logout successfully");
			}
		}
		LOGGER.info("Exit from BankService :: appLoginOut()");
		return loginResponse;
	}

	@Override
	public AccountResponse addAccount(final AccountRequest accountRequest) {
		LOGGER.info("Enter in BankService :: addAccount()");
		final AccountResponse accountResponse = new AccountResponse();
		final Account account = new AccountMapper().convertDtoToEntity(accountRequest.getAccount());
		accountRepository.save(account);
		accountResponse.setCode("ACCOUNT_CREATED");
		accountResponse.setMessage("Hey User .. Congrats your account created sucessfully");
		LOGGER.info("Exit from BankService :: addAccount()");
		return accountResponse;
	}

	@Override
	public AccountResponse viewAccountById(AccountRequest accountRequest) {
		LOGGER.info("Enter in BankService :: viewAccountById()");
		final AccountResponse accountResponse = new AccountResponse();
		final Account account = new AccountMapper().convertDtoToEntity(accountRequest.getAccount());
		final Account accountRes = accountRepository.findAccountById(account.getAccountId());
		final AccountDto accountDto = new AccountMapper().convertEntityToDto(accountRes);
		accountResponse.setCode("ACCOUNT_VIEWED");
		accountResponse.setMessage("Hey User .. Congrats your account view sucessfully");
		final List<AccountDto> accountList = new ArrayList<>();
		accountList.add(accountDto);
		accountResponse.setAccounts(accountList);
		LOGGER.info("Exit from BankService :: viewAccountById()");
		return accountResponse;
	}

	@Override
	public AccountResponse viewAccountByBranch(AccountRequest accountRequest) {
		LOGGER.info("Enter in BankService :: viewAccountByBranch()");
		final AccountResponse accountResponse = new AccountResponse();
		final List<AccountDto> accountList = new ArrayList<>();
		final Account account = new AccountMapper().convertDtoToEntity(accountRequest.getAccount());
		final List<Account> accountResList = accountRepository.findAccountByBranch(account.getAccountBranch());
		for (Account accountRes : accountResList) {
			final AccountDto accountDto = new AccountMapper().convertEntityToDto(accountRes);
			accountList.add(accountDto);
		}
		accountResponse.setCode("ACCOUNT_VIEWED");
		accountResponse.setMessage("Hey User .. Congrats your account view sucessfully");
		accountResponse.setAccounts(accountList);
		LOGGER.info("Exit from BankService :: viewAccountByBranch()");
		return accountResponse;
	}

	@Override
	public AccountResponse viewAccountByAcctType(AccountRequest accountRequest) {
		LOGGER.info("Enter in BankService :: viewAccountByAcctType()");
		final AccountResponse accountResponse = new AccountResponse();
		final List<AccountDto> accountList = new ArrayList<>();
		final Account account = new AccountMapper().convertDtoToEntity(accountRequest.getAccount());
		final List<Account> accountResList = accountRepository.findAccountByType(account.getAccountType());
		for (Account accountRes : accountResList) {
			final AccountDto accountDto = new AccountMapper().convertEntityToDto(accountRes);
			accountList.add(accountDto);
		}
		accountResponse.setCode("ACCOUNT_VIEWED");
		accountResponse.setMessage("Hey User .. Congrats your account view sucessfully");
		accountResponse.setAccounts(accountList);
		LOGGER.info("Exit from BankService :: viewAccountByAcctType()");
		return accountResponse;
	}

	@Override
	public AccountResponse deleteAccount(final AccountRequest accountRequest) {
		LOGGER.info("Enter in BankService :: deleteAccount()");
		final AccountResponse accountResponse = new AccountResponse();
		final Account account = new AccountMapper().convertDtoToEntity(accountRequest.getAccount());
		accountRepository.deleteById(account.getAccountId());
		accountResponse.setCode("ACCOUNT_DELETED");
		accountResponse.setMessage("Hey User .. Congrats your account deleted sucessfully");
		LOGGER.info("Exit from BankService :: deleteAccount()");
		return accountResponse;
	}

	@Override
	public TransactionResponse accountDeposit(final TransactionRequest transactionRequest) {
		LOGGER.info("Enter in BankService :: accountDeposit()");
		final TransactionResponse transactionResponse = new TransactionResponse();
		final TransactionDto transactionDto = transactionRequest.getTransaction();
		final Account accountRes = accountRepository.findAccountById(transactionDto.getAccount().getAccountId());
		accountRes.setAccountBalance(accountRes.getAccountBalance().add(transactionDto.getAmount()));
		accountRepository.save(accountRes);
		final Transaction transaction = new TransactionMapper().convertDtoToEntity(transactionDto);
		transactionRepository.save(transaction);
		transactionResponse.setCode("ACCOUNT_DEPOSITED");
		transactionResponse.setMessage("Hey User .. Congrats your account deposited Rs : "+transactionDto.getAmount()+"sucessfully");
		LOGGER.info("Exit from BankService :: accountDeposit()");
		return transactionResponse;
	}

	@Override
	public TransactionResponse accountWithdraw(final TransactionRequest transactionRequest) {
		LOGGER.info("Enter in BankService :: accountWithdraw()");
		final TransactionResponse transactionResponse = new TransactionResponse();
		final TransactionDto transactionDto = transactionRequest.getTransaction();
		final Account accountRes = accountRepository.findAccountById(transactionDto.getAccount().getAccountId());
		if(accountRes.getAccountBalance().compareTo(transactionDto.getAmount())>0){
			accountRes.setAccountBalance(accountRes.getAccountBalance().subtract(transactionDto.getAmount()));
			accountRepository.save(accountRes);
			final Transaction transaction = new TransactionMapper().convertDtoToEntity(transactionDto);
			transactionRepository.save(transaction);
			transactionResponse.setCode("ACCOUNT_WITHDRAW");
			transactionResponse.setMessage("Hey User .. Congrats your account withdraw Rs : "+transactionDto.getAmount()+"sucessfully");
		}else{
			transactionResponse.setCode("ACCOUNT_WITHDRAW");
			transactionResponse.setMessage("Hey User .. your account withdraw Rs : "+transactionDto.getAmount()+"failed");
		}
		LOGGER.info("Exit from BankService :: accountWithdraw()");
		return transactionResponse;
	}

	@Override
	public AccountTypeResponse getAccountType() {
		LOGGER.info("Enter in BankService :: getAccountType()");
		final AccountTypeResponse accountTypeResponse =new AccountTypeResponse();
		final List<AccountTypeDto> accountTypeDtoList = new ArrayList<>();
		final Iterable<AccountType> accountTypIterator = accountTypeRepository.findAll();
		if(null != accountTypIterator){
			for (AccountType accountType : accountTypIterator) {
				final AccountTypeDto accountTypeDto = new AccountTypeMapper().convertEntityToDto(accountType);
				accountTypeDtoList.add(accountTypeDto);
			}
		}else{
			accountTypeResponse.setCode("NO_RECORD_FOUND");
			accountTypeResponse.setMessage("Something went wrong .. No record found");
		}
		accountTypeResponse.setAccountTypes(accountTypeDtoList);
		LOGGER.info("Exit from BankService :: getAccountType()");
		return accountTypeResponse;
	}

	@Override
	public BranchResponse getBranch() {
		LOGGER.info("Enter in BankService :: getBranch()");
		final BranchResponse branchResponse = new BranchResponse();
		final List<AccountBranchDto> accountBranchDtoList = new ArrayList<>();
		//accountBranchRepository.findAll().forEach(e -> accountBranchDtoList.add(e));
		final Iterable<AccountBranch> accountBranchIterator = accountBranchRepository.findAll();
		if(null != accountBranchIterator){
			for (AccountBranch accountBranch : accountBranchIterator) {
				final AccountBranchDto accountBranchDto = new AccountBranchMapper().convertEntityToDto(accountBranch);
				accountBranchDtoList.add(accountBranchDto);
			}
		}else{
			branchResponse.setCode("NO_RECORD_FOUND");
			branchResponse.setMessage("Something went wrong .. No record found");
		}
		branchResponse.setAccountBranch(accountBranchDtoList);
		LOGGER.info("Exit from BankService :: getBranch()");
		return branchResponse;
	}


	@Override
	public TransactionResponse viewStatement(final TransactionRequest transactionRequest) {
		LOGGER.info("Enter in BankService :: viewStatement()");
		final TransactionResponse transactionResponse = new TransactionResponse();
		final List<TransactionDto> transactionDtoList = new ArrayList<>();
		final Transaction transactionRes = new TransactionMapper().convertDtoToEntity(transactionRequest.getTransaction());
		final List<Transaction> transactionList = transactionRepository.findTransactionByAcctIdAndTransType
				(transactionRes.getAccount().getAccountId(), transactionRes.getTransactionType());
		for (Transaction transaction : transactionList) {
			final TransactionDto transactionDto = new TransactionMapper().convertEntityToDto(transaction);
			transactionDtoList.add(transactionDto);
		}
		transactionResponse.setCode("ACCOUNT_STATEMENT");
		transactionResponse.setMessage("Hey User .. Congrats your statement view sucessfully");
		transactionResponse.setTransactions(transactionDtoList);
		LOGGER.info("Exit from BankService :: viewStatement()");
		return transactionResponse;
	}

}
