package com.bank.example.repository;

import org.springframework.data.repository.CrudRepository;

import com.bank.example.entity.AccountType;

public interface AccountTypeRepository extends CrudRepository<AccountType,Long>{

}
