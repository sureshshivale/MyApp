package com.bank.example.mapper;

import java.util.ArrayList;
import java.util.List;

import com.bank.example.dto.AccountDto;
import com.bank.example.dto.TransactionDto;
import com.bank.example.entity.Account;
import com.bank.example.entity.Transaction;

public class AccountMapper implements IMapper<AccountDto, Account>{

	@Override
	public Account convertDtoToEntity(AccountDto dto) {
		final Account entity = new Account();
		entity.setAccountId(dto.getAccountId());
		entity.setAccountName(dto.getAccountName());
		entity.setAccountType(dto.getAccountType());
		entity.setAccountBalance(dto.getAccountBalance());
		entity.setAccountBranch(dto.getAccountBranch());
		final List<Transaction> transactionEntityList = new ArrayList<>();
		final List<TransactionDto> transactionDtoList = dto.getTransactions();
		if(null != transactionDtoList && !transactionDtoList.isEmpty()){
			for (TransactionDto transactionDto : transactionDtoList) {
				transactionEntityList.add(new TransactionMapper().convertDtoToEntity(transactionDto));
			}
		}
		entity.setTransactions(transactionEntityList);
		return entity;
	}

	@Override
	public AccountDto convertEntityToDto(Account entity) {
		final AccountDto dto = new AccountDto();
		dto.setAccountId(entity.getAccountId());
		dto.setAccountName(entity.getAccountName());
		dto.setAccountType(entity.getAccountType());
		dto.setAccountBalance(entity.getAccountBalance());
		dto.setAccountBranch(entity.getAccountBranch());
		final List<TransactionDto> transactionDtoList = new ArrayList<>();
		final List<Transaction> transactionEntityList = entity.getTransactions();
		if(null != transactionEntityList && !transactionEntityList.isEmpty()){
			for (Transaction transactionEntity : transactionEntityList) {
				transactionDtoList.add(new TransactionMapper().convertEntityToDto(transactionEntity));
			}
		}
		dto.setTransactions(transactionDtoList);
		return dto;
	}

}
