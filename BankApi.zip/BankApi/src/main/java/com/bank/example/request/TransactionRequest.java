package com.bank.example.request;

import java.io.Serializable;

import com.bank.example.dto.TransactionDto;

public class TransactionRequest implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private TransactionDto transaction;

	public TransactionDto getTransaction() {
		return transaction;
	}

	public void setTransaction(TransactionDto transaction) {
		this.transaction = transaction;
	}
	
}
