package com.bank.example.dto;

import java.io.Serializable;

public class AccountTypeDto implements Serializable {
	private static final long serialVersionUID = 1L;

	private long accountTypeId;
	private String accountTypeName;
	
	public long getAccountTypeId() {
		return accountTypeId;
	}
	public void setAccountTypeId(long accountTypeId) {
		this.accountTypeId = accountTypeId;
	}
	public String getAccountTypeName() {
		return accountTypeName;
	}
	public void setAccountTypeName(String accountTypeName) {
		this.accountTypeName = accountTypeName;
	}
	

}