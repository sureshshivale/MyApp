package com.bank.example.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.bank.example.entity.Account;

public interface AccountRepository extends CrudRepository<Account,Long>{


	@Query("SELECT account FROM Account account WHERE account.accountId=:accountId")
	Account findAccountById(@Param("accountId") Long accountId);
	
	@Query("SELECT account FROM Account account WHERE account.accountBranch=:accountBranch")
	List<Account> findAccountByBranch(@Param("accountBranch") String accountBranch);
	
	@Query("SELECT account FROM Account account WHERE account.accountType=:accountType")
	List<Account> findAccountByType(@Param("accountType") String accountType);
}
