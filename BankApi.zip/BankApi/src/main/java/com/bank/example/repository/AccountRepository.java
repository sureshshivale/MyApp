package com.bank.example.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.bank.example.entity.Account;

public interface AccountRepository extends CrudRepository<Account,Long>{

	@Query
	Account findAccountById(Long accountId);
	//List<Account> findAccountByBranch(String accountBranch);
	//List<Account> findAccountByType(String accountType);
}
