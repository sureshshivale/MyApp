package com.bank.example.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the ACCOUNT_BRANCH database table.
 * 
 */
@Entity
@Table(name="ACCOUNT_BRANCH")
public class AccountBranch implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="ACCOUNT_BRANCH_ACCOUNTBRANCHID_GENERATOR" )
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="ACCOUNT_BRANCH_ACCOUNTBRANCHID_GENERATOR")
	@Column(name="ACCOUNT_BRANCH_ID")
	private long accountBranchId;

	@Column(name="ACCOUNT_BRANCH_NAME")
	private String accountBranchName;

	public long getAccountBranchId() {
		return accountBranchId;
	}

	public void setAccountBranchId(long accountBranchId) {
		this.accountBranchId = accountBranchId;
	}

	public String getAccountBranchName() {
		return accountBranchName;
	}

	public void setAccountBranchName(String accountBranchName) {
		this.accountBranchName = accountBranchName;
	}
	
}