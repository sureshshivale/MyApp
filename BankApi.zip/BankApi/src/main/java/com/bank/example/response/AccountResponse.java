package com.bank.example.response;

import java.io.Serializable;

import com.bank.example.dto.AccountDto;

public class AccountResponse extends ResponseMessage implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private AccountDto account;

	public AccountDto getAccount() {
		return account;
	}

	public void setAccount(AccountDto account) {
		this.account = account;
	}
}
