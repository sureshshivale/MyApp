package com.bank.example.response;

import java.io.Serializable;
import java.util.List;

import com.bank.example.dto.AccountDto;

public class AccountResponse extends ResponseMessage implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private List<AccountDto> accounts;

	public List<AccountDto> getAccounts() {
		return accounts;
	}

	public void setAccounts(List<AccountDto> accounts) {
		this.accounts = accounts;
	}
}	
