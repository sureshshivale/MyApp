package com.bank.example.mapper;

import com.bank.example.dto.TransactionDto;
import com.bank.example.entity.Transaction;

public class TransactionMapper implements IMapper<TransactionDto, Transaction>{

	@Override
	public Transaction convetDtoToEntity(TransactionDto dto) {
		final Transaction entity = new Transaction();
		entity.setAccount(new AccountMapper().convetDtoToEntity(dto.getAccount()));
		entity.setAmount(dto.getAmount());
		entity.setTransactionDate(dto.getTransactionDate());
		entity.setTransactionId(dto.getTransactionId());
		entity.setTransactionType(dto.getTransactionType());
		return entity;
	}

	@Override
	public TransactionDto convertEntityToDto(Transaction entity) {
		final TransactionDto dto = new TransactionDto();
		dto.setAccount(new AccountMapper().convertEntityToDto(entity.getAccount()));
		dto.setAmount(entity.getAmount());
		dto.setTransactionDate(entity.getTransactionDate());
		dto.setTransactionId(entity.getTransactionId());
		dto.setTransactionType(entity.getTransactionType());
		return dto;
	}


}
