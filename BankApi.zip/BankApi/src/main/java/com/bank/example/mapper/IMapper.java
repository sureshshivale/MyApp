package com.bank.example.mapper;

public interface IMapper<Dto,Entity> {

	Entity convetDtoToEntity(Dto dto);
	
	Dto convertEntityToDto(Entity entity);
}
