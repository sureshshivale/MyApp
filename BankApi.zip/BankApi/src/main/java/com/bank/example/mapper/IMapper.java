package com.bank.example.mapper;

public interface IMapper<Dto,Entity> {

	Entity convertDtoToEntity(Dto dto);
	
	Dto convertEntityToDto(Entity entity);
}
