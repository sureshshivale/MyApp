package com.bank.example.controller;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bank.example.dto.AccountDto;
import com.bank.example.dto.BankUserDto;
import com.bank.example.dto.TransactionDto;
import com.bank.example.request.AccountRequest;
import com.bank.example.request.LoginRequest;
import com.bank.example.request.TransactionRequest;
import com.bank.example.response.AccountResponse;
import com.bank.example.response.AccountTypeResponse;
import com.bank.example.response.BranchResponse;
import com.bank.example.response.LoginResponse;
import com.bank.example.response.TransactionResponse;
import com.bank.example.service.IBankService;

@RestController
@RequestMapping("/bank/account")
public class BankController {

	@Autowired
	private IBankService bankService;

	final Logger LOGGER = LoggerFactory.getLogger(BankController.class);
	
	@GetMapping(value="/login",produces = MediaType.APPLICATION_JSON_VALUE)
	public LoginResponse appLogin(@RequestParam("userName") final String userName,@RequestParam("password") final String password){
		LOGGER.info("Enter in BankController :: appLogin()");
		final LoginRequest loginRequest = new LoginRequest();
		final BankUserDto bankUser = new BankUserDto();
		bankUser.setUserName(userName);
		bankUser.setPassword(password);
		loginRequest.setBankUser(bankUser);
		final LoginResponse loginResponse = bankService.appLogin(loginRequest);
		LOGGER.info("Exit from BankController :: appLogin()");
		return loginResponse;
		
	}
	
	@PutMapping(value="/logout", consumes=MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public LoginResponse appLoginOut(@RequestBody final LoginRequest loginRequest){
		LOGGER.info("Enter in BankController :: appLoginOut()");
		final LoginResponse loginResponse = bankService.appLoginOut(loginRequest);
		LOGGER.info("Exit from BankController :: appLoginOut()");
		return loginResponse;
		
	}
	
	@GetMapping(value="/type",produces = MediaType.APPLICATION_JSON_VALUE)
	public AccountTypeResponse getAccountType(){
		LOGGER.info("Enter in BankController :: getAccountType()");
		final AccountTypeResponse accountTypeResponse = bankService.getAccountType();
		LOGGER.info("Exit from BankController :: getAccountType()");
		return accountTypeResponse;
		
	}
	
	@GetMapping(value="/branch",produces = MediaType.APPLICATION_JSON_VALUE)
	public BranchResponse getBranch(){
		LOGGER.info("Enter in BankController :: getBranch()");
		final BranchResponse branchResponse = bankService.getBranch();
		LOGGER.info("Exit from BankController :: getBranch()");
		return branchResponse;
		
	}
	
	@PostMapping(value="/create", consumes=MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public AccountResponse addAccount(@RequestBody final AccountRequest accountRequest){
		LOGGER.info("Enter in BankController :: addAccount()");
		final AccountResponse accountResponse = bankService.addAccount(accountRequest);
		LOGGER.info("Exit from BankController :: addAccount()");
		return accountResponse;
		
	}
	
	@GetMapping(value="/view/byid/{accountid}",produces = MediaType.APPLICATION_JSON_VALUE)
	public AccountResponse viewAccountById(@PathVariable("accountid") final Long accountId){
		LOGGER.info("Enter in BankController :: viewAccountById()");
		final AccountRequest accountRequest = new AccountRequest();
		final AccountDto accountDto = new AccountDto();
		accountDto.setAccountId(accountId);
		accountRequest.setAccount(accountDto);
		final AccountResponse accountResponse = bankService.viewAccountById(accountRequest);
		LOGGER.info("Exit from BankController :: viewAccountById()");
		return accountResponse;
		
	}
	
	@GetMapping(value="/view/bybranch{accountBranch}",produces = MediaType.APPLICATION_JSON_VALUE)
	public AccountResponse viewAccountByBranch(@PathVariable("accountBranch") final String accountBranch){
		LOGGER.info("Enter in BankController :: viewAccountByBranch()");
		final AccountRequest accountRequest = new AccountRequest();
		final AccountDto accountDto = new AccountDto();
		accountDto.setAccountBranch(accountBranch);
		accountRequest.setAccount(accountDto);
		final AccountResponse accountResponse = bankService.viewAccountByBranch(accountRequest);
		LOGGER.info("Exit from BankController :: viewAccountByBranch()");
		return accountResponse;
		
	}
	
	@GetMapping(value="/view/bybranch{accountType}",produces = MediaType.APPLICATION_JSON_VALUE)
	public AccountResponse viewAccountByAcctType(@PathVariable("accountType") final String accountType){
		LOGGER.info("Enter in BankController :: viewAccountByAcctType()");
		final AccountRequest accountRequest = new AccountRequest();
		final AccountDto accountDto = new AccountDto();
		accountDto.setAccountType(accountType);
		accountRequest.setAccount(accountDto);
		final AccountResponse accountResponse = bankService.viewAccountByAcctType(accountRequest);
		LOGGER.info("Exit from BankController :: viewAccountByAcctType()");
		return accountResponse;
		
	}
	
	@DeleteMapping(value="/manage/delete/{accountid}",produces = MediaType.APPLICATION_JSON_VALUE)
	public AccountResponse deleteAccount(@PathVariable("accountid") final Long accountId){
		LOGGER.info("Enter in BankController :: deleteAccount()");
		final AccountRequest accountRequest = new AccountRequest();
		final AccountDto accountDto = new AccountDto();
		accountDto.setAccountId(accountId);
		accountRequest.setAccount(accountDto);
		final AccountResponse accountResponse = bankService.deleteAccount(accountRequest);
		LOGGER.info("Exit from BankController :: deleteAccount()");
		return accountResponse;
		
	}
	
	@PutMapping(value="/manage/deposit", consumes=MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public TransactionResponse accountDeposit(@RequestBody final TransactionRequest transactionRequest){
		LOGGER.info("Enter in BankController :: accountDeposit()");
		final TransactionResponse transactionResponse = bankService.accountDeposit(transactionRequest);
		LOGGER.info("Exit from BankController :: accountDeposit()");
		return transactionResponse;
		
	}
	
	@PutMapping(value="/manage/withdraw", consumes=MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public TransactionResponse accountWithdraw(@RequestBody final TransactionRequest transactionRequest){
		LOGGER.info("Enter in BankController :: accountWithdraw()");
		final TransactionResponse transactionResponse = bankService.accountWithdraw(transactionRequest);
		LOGGER.info("Exit from BankController :: accountWithdraw()");
		return transactionResponse;
		
	}
	
	@GetMapping(value="/statement",produces = MediaType.APPLICATION_JSON_VALUE)
	public TransactionResponse viewStatement(@RequestParam(name = "accountId") final Long accountId,
			@RequestParam(name = "transactionType") final String transactionType){
		LOGGER.info("Enter in BankController :: viewStatement()");
		final TransactionRequest transactionRequest = new TransactionRequest();
		final TransactionDto transactionDto = new TransactionDto();
		transactionDto.setTransactionType(transactionType);
		final AccountDto accountDto = new AccountDto();
		accountDto.setAccountId(accountId);
		transactionDto.setAccount(accountDto);
		transactionRequest.setTransaction(transactionDto);
		final TransactionResponse transactionResponse = bankService.viewStatement(transactionRequest);
		LOGGER.info("Exit from BankController :: viewStatement()");
		return transactionResponse;
		
	}
}
