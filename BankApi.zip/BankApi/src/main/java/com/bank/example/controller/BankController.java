package com.bank.example.controller;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bank.example.dto.AccountDto;
import com.bank.example.dto.BankUserDto;
import com.bank.example.request.AccountRequest;
import com.bank.example.request.LoginRequest;
import com.bank.example.request.TransactionRequest;
import com.bank.example.response.AccountResponse;
import com.bank.example.response.AccountTypeResponse;
import com.bank.example.response.BranchResponse;
import com.bank.example.response.LoginResponse;
import com.bank.example.response.TransactionResponse;
import com.bank.example.service.IBankService;

@RestController
@RequestMapping("/bank/account")
public class BankController {

	@Autowired
	private IBankService bankService;

	final Logger LOGGER = LoggerFactory.getLogger(BankController.class);
	
	@GetMapping(value="/login",produces = MediaType.APPLICATION_JSON_VALUE)
	public LoginResponse appLogin(@RequestParam("userName") final String userName,@RequestParam("password") final String password){
		LOGGER.info("Enter in BankController :: appLogin()");
		final LoginRequest loginRequest = new LoginRequest();
		final BankUserDto bankUser = new BankUserDto();
		bankUser.setUserName(userName);
		bankUser.setPassword(password);
		loginRequest.setBankUser(bankUser);
		final LoginResponse loginResponse = bankService.appLogin(loginRequest);
		LOGGER.info("Exit from BankController :: appLogin()");
		return loginResponse;
		
	}
	
	@PutMapping(value="/logout", consumes=MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public LoginResponse appLoginOut(@RequestBody final LoginRequest loginRequest){
		LOGGER.info("Enter in BankController :: appLoginOut()");
		final LoginResponse loginResponse = bankService.appLoginOut(loginRequest);
		LOGGER.info("Exit from BankController :: appLoginOut()");
		return loginResponse;
		
	}
	
	@GetMapping(value="/type",produces = MediaType.APPLICATION_JSON_VALUE)
	public AccountTypeResponse getAccountType(){
		LOGGER.info("Enter in BankController :: getAccountType()");
		final AccountTypeResponse accountTypeResponse = bankService.getAccountType();
		LOGGER.info("Exit from BankController :: getAccountType()");
		return accountTypeResponse;
		
	}
	
	@GetMapping(value="/branch",produces = MediaType.APPLICATION_JSON_VALUE)
	public BranchResponse getBranch(){
		LOGGER.info("Enter in BankController :: getBranch()");
		final BranchResponse branchResponse = bankService.getBranch();
		LOGGER.info("Exit from BankController :: getBranch()");
		return branchResponse;
		
	}
	
	@PostMapping(value="/create", consumes=MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public AccountResponse addAccount(@RequestBody final AccountRequest accountRequest){
		LOGGER.info("Enter in BankController :: addAccount()");
		final AccountResponse accountResponse = bankService.addAccount(accountRequest);
		LOGGER.info("Exit from BankController :: addAccount()");
		return accountResponse;
		
	}
	
	@GetMapping(value="/view/{accountid}",produces = MediaType.APPLICATION_JSON_VALUE)
	public AccountResponse viewAccount(@PathVariable("accountid") final Long accountId){
		LOGGER.info("Enter in BankController :: viewAccount()");
		final AccountRequest accountRequest = new AccountRequest();
		final AccountDto accountDto = new AccountDto();
		accountDto.setAccountId(accountId);
		accountRequest.setAccount(accountDto);
		final AccountResponse accountResponse = bankService.viewAccount(accountRequest);
		LOGGER.info("Exit from BankController :: viewAccount()");
		return accountResponse;
		
	}
	
	@DeleteMapping(value="/manage/{accountid}",produces = MediaType.APPLICATION_JSON_VALUE)
	public AccountResponse deleteAccount(@PathVariable("accountid") final String accountId){
		LOGGER.info("Enter in BankController :: deleteAccount()");
		LOGGER.info("Exit from BankController :: deleteAccount()");
		return null;
		
	}
	
	@PutMapping(value="/deposit", consumes=MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public TransactionResponse accountDeposit(@RequestBody final TransactionRequest transactionRequest){
		LOGGER.info("Enter in BankController :: accountDeposit()");
		LOGGER.info("Exit from BankController :: accountDeposit()");
		return null;
		
	}
	
	@PutMapping(value="/withdraw", consumes=MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public TransactionResponse accountWithdraw(@RequestBody final TransactionRequest transactionRequest){
		LOGGER.info("Enter in BankController :: accountWithdraw()");
		LOGGER.info("Exit from BankController :: accountWithdraw()");
		return null;
		
	}
	
}
